from constants import *

class Milestone :

    m01_Npav_Date :str
    m02_Caav_Date : str
    m03_Prkf_Date : str
    m04_Reqf_Date : str
    m05_Soco_Date : str
    m06_Desf_Date : str
    m07_Iarv_Date : str
    m08_Togo_Date : str
    m09_Ofto_Date : str
    m10_Otop_Date : str
    m11_Isva_Date : str
    m12_Sopr_Date : str
    m13_Sop_Date : str
    m14_Prcl_Date : str

    currentMilestone : str

    startColumnIndex : int
    currentColumnIndex : int

    def getMilestoneDate(self, milestone):
        if milestone == "M1-NPAV":
            if (m01_Npav_Date != "") :
                tempDate = m01_Npav_Date
            
        if milestone == "M2-CAAV":
            if (m02_Caav_Date != "") :
                tempDate = m02_Caav_Date
            
        
        if milestone == "M3-PRKF":
            if (m03_Prkf_Date != "") :
                tempDate = m03_Prkf_Date
        
        
        if milestone == "M4-REQF":
            if (m04_Reqf_Date != "") :
                tempDate = m04_Reqf_Date
        
        
        if milestone == "M5-SOCO":
            if (m05_Soco_Date != "") :
                tempDate = m05_Soco_Date
        
        
        if milestone == "M6-DESF":
            if (m06_Desf_Date != "") :
                tempDate = m06_Desf_Date
        
        
        if milestone == "M7-IARV":
            if (m07_Iarv_Date != "") :
                tempDate = m07_Iarv_Date
            
        
        if milestone == "M8-TOGO":
            if (m08_Togo_Date != "") :
                tempDate = m08_Togo_Date
            
        
        if milestone == "M9-OFTO":
            if (m09_Ofto_Date != "") :
                tempDate = m09_Ofto_Date
            
        
        if milestone == "M10-OTOP":
            if (m10_Otop_Date != "") :
                tempDate = m10_Otop_Date
            
            
        if milestone == "M11-ISVA":
            if (m11_Isva_Date != "") :
                tempDate = m11_Isva_Date
            
        
        if milestone == "M12-SOPR":
            if (m12_Sopr_Date != "") :
                tempDate = m12_Sopr_Date
            
        
        if milestone == "M13-SOP":
            if (m13_Sop_Date != "") :
                tempDate = m13_Sop_Date
            
        
        if milestone == "M14-PRCL":
            if (m14_Prcl_Date != "") :
                tempDate = m14_Prcl_Date

        return  tempDate



    def getDates(self, startIndex, sheet) :
    
        milestoneCollection = set([])

        m01_Npav_Date = sheet.cell_value(startIndex, EDRM_M1_NPAV_COLUMN)
        milestoneCollection.add(m01_Npav_Date)
        
        m02_Caav_Date = sheet.cell_value(startIndex, EDRM_M2_CAAV_COLUMN)
        milestoneCollection.add(m02_Caav_Date)
        
        m03_Prkf_Date = sheet.cell_value(startIndex, EDRM_M3_PRKF_COLUMN)
        milestoneCollection.add(m03_Prkf_Date)
        
        m04_Reqf_Date = sheet.cell_value(startIndex, EDRM_M4_REQF_COLUMN)
        milestoneCollection.add(m04_Reqf_Date)
        
        m05_Soco_Date = sheet.cell_value(startIndex, EDRM_M5_SOCO_COLUMN)
        milestoneCollection.add(m05_Soco_Date)
        
        m06_Desf_Date = sheet.cell_value(startIndex, EDRM_M6_DESF_COLUMN)
        milestoneCollection.add(m06_Desf_Date)
        
        m07_Iarv_Date = sheet.cell_value(startIndex, EDRM_M7_IARV_COLUMN)
        milestoneCollection.add(m07_Iarv_Date)
        
        m08_Togo_Date = sheet.cell_value(startIndex, EDRM_M8_TOGO_COLUMN)
        milestoneCollection.add(m08_Togo_Date)
        
        m09_Ofto_Date = sheet.cell_value(startIndex, EDRM_M9_OFTO_COLUMN)
        milestoneCollection.add(m09_Ofto_Date)
        
        m10_Otop_Date = sheet.cell_value(startIndex, EDRM_M10_OTOP_COLUMN)
        milestoneCollection.add(m10_Otop_Date)
        
        m11_Isva_Date = sheet.cell_value(startIndex, EDRM_M11_ISVA_COLUMN)
        milestoneCollection.add(m11_Isva_Date)
        
        m12_Sopr_Date = sheet.cell_value(startIndex, EDRM_M12_SOPR_COLUMN)
        milestoneCollection.add(m12_Sopr_Date)
        
        m13_Sop_Date = sheet.cell_value(startIndex, EDRM_M13_SOP_COLUMN)
        milestoneCollection.add(m13_Sop_Date)
        
        m14_Prcl_Date = sheet.cell_value(startIndex, EDRM_M14_PRCL_COLUMN)
                
        currentMilestone = sheet.cell_value(startIndex, EDRM_CURRENT_MILESTONE_COLUMN)
        