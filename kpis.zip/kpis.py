import xlrd 
import os
import datetime
import re
from milestones import Milestone
from constants import *

BASE_DIR = os.getcwd()
SHEET_NAME = 'Book1.xlsx'
sheet_path = os.path.join(BASE_DIR, SHEET_NAME)

cntGreenReviews : int
cntRedReviews  : int
cntYellowReviews  : int 
cntSwReviews  :int
noSwIdentified  : bool

overallSituation : str
caavReviewDate: str
compMDBRebviewDate : str

def compute_data(row_index):
    
    wb = xlrd.open_workbook(sheet_path) 
    sheet = wb.sheet_by_index(0) 

    '''#PRKF
    PRKFDate = sheet.cell_value(row_index, EDRM_M3_PRKF_DATE_COLUMN)
    
    #PG
    PGName = sheet.cell_value(row_index, EDRM_PG_NAME_COLUMN)
    
    #PL
    PLName = sheet.cell_value(row_index, EDRM_PL_NAME_COLUMN)
    
    #Project Name
    projectName = sheet.cell_value(row_index, EDRM_PROJECT_NAME_COLUMN)
    
    #Element Name
    elementName = sheet.cell_value(row_index, EDRM_ELEMENT_NAME_COLUMN)
    
    #Project Code
    projectCode = sheet.cell_value(row_index, EDRM_PROJECT_CODE_COLUMN)
    
    #SoP date
    if sheet.cell_value(row_index, EDRM_IL_COLUMN) == "" :
        sopDate = "Undefined"
    else :
        sopDate = sheet.cell_value(row_index, EDRM_ASIL_COLUMN)
        sopDate = datetime.datetime.strftime(sopDate, "dd/mm/yyyy")

    '''    
    #Element - Validated Sw Risk Level1
    swRisk = sheet.cell_value(row_index, EDRM_SW_RISK_PROPOSED_COLUMN)
    swRiskproposed = sheet.cell_value(row_index, EDRM_SW_RISK_VALIDATED_COLUMN)

    #Element - ASIL
    if sheet.cell_value(row_index, EDRM_ASIL_COLUMN) == "" :
        asil = "Undefined"
    else :
        asil = sheet.cell_value(row_index, EDRM_ASIL_COLUMN)

    setReviewDates(row_index, sheet, asil)
    
    elaborateOverallSituation()

    milestones = Milestone()
    milestones.getDates(row_index, sheet)


    #-----------------------------------------------------------------------------------------------------
    #                                               TR CAAV
    #------------------------------------------------------------------------------------------------------
    #Set default values
    CaavNOTonTrack = False
    CaavDRPlanned = True
    
    #Check that TR CAAV is applicable
    if (caavReviewDate != "NA" and caavReviewDate != "No sw reviews identified under eDRM" and 
       caavReviewDate != "Green" and  caavReviewDate != "Yellow" and caavReviewDate != "") :

        #Check that TR CAAV is scheduled
        if ((caavReviewDate == "Red") or (caavReviewDate == "Orange") or
            (caavReviewDate == "To be planned") or
            (caavReviewDate == "In progress")) :
            CaavDRPlanned = False
        else :
            d1 = datetime.datetime(caavReviewDate) 
            d2 = datetime.datetime.now()                    
            #Check that the review date is above the current date
            if(d1 > d2):
                CaavDRPlanned = False

            d3 = datetime.datetime(milestones.getMilestoneDate("M3-PRKF"))  
            #Check that the review date is within its milestone
            if(d1 > d3) :
                CaavNOTonTrack = True
    

def setReviewDates(i, sheet, asil):
    global cntGreenReviews
    global cntRedReviews
    global cntYellowReviews
    global cntSwReviews
    global noSwIdentified 

    drTypes = ["CAAV", "Archi", "Comp", "VTP", "ITP", "SRS_Overall", "SDP_Full", "SRS_Features", "SDP_Init"]

    #check "Last DR Result" of sw reviews
    if (sheet.cell_value(i, EDRM_DR_TYPE_COLUMN) in drTypes  or
        re.search(".*SDP_Init.*", sheet.cell_value(i, EDRM_DR_TYPE_COLUMN))):
        #Return findings
        lastDRResult = sheet.cell_value(i, EDRM_LAST_DR_RESULT_COLUMN)
        tempGeneralFindings = sheet.cell_value(i, EDRM_GENERAL_COMMENTS_COLUMN)
        tempProcessFindings = sheet.cell_value(i, EDRM_PROCESS_MAJOR_FINDINGS_COLUMN)
        tempTechnicalFindings = sheet.cell_value(i, EDRM_TECHNICAL_MAJOR_FINDINGS_COLUMN)
        tempGeneralFindings = tempGeneralFindings.replace("=>", ">")
        tempProcessFindings = tempProcessFindings.replace("=>", ">")
        tempTechnicalFindings = tempTechnicalFindings.replace("=>", ">")
                        
        if sheet.cell_value(i, EDRM_MEETING_LifE_CYCLE_COLUMN) == "Not Applicable" :         
            tempText = "NA"
            
        #Check "Next Date"
        elif sheet.cell_value(i, EDRM_NEXT_DATE_COLUMN) != "" :
            #Last "Next Date" is not empty
            #Return date
            tempText = sheet.cell_value(i, EDRM_NEXT_DATE_COLUMN)
            
        #check "Last DR Result" of sw reviews
        elif sheet.cell_value(i, EDRM_LAST_DR_RESULT_COLUMN) != "" :
            #Last "Next Date" is empty
            #Last DR status is not empty
            #Return status
            tempText = sheet.cell_value(i, EDRM_LAST_DR_RESULT_COLUMN)
            
            #Count Red statuses
            if tempText == "Red" :
                cntRedReviews = cntRedReviews + 1
                
            #Count Yellow statuses
            elif tempText == "Yellow" :
                cntYellowReviews = cntYellowReviews + 1
            
            #Count Green statuses
            else :
                cntGreenReviews = cntGreenReviews + 1     

        else:
            #Last "Next Date" is empty
            tempText = "To be planned"
            
        ''' ------------------------------------------------------------------------------------------------------------------------ '''
            
            
        #Default values
        global caavReviewDate
        global compMDBRebviewDate
        
        caavReviewDate = "NA"
        compMDBRebviewDate = "NA"

        drType = sheet.cell_value(i, EDRM_DR_TYPE_COLUMN)    
        if drType == "CAAV":
            caavReviewDate = tempText
            caavLastDRResult = lastDRResult
            caavGeneralFindings = tempGeneralFindings
            caavProcessFindings = tempProcessFindings
            cavvTechnicalFindings = tempTechnicalFindings
            noSwIdentified = False
            cntSwReviews = cntSwReviews + 1
            
        if drType == "SDP_Init/Light":
            sdpInitReviewDate = tempText
            sdpInitLastDRResult = lastDRResult
            sdpInitGeneralFindings = tempGeneralFindings
            sdpInitProcessFindings = tempProcessFindings
            sdpInitTechnicalFindings = tempTechnicalFindings
            noSwIdentified = False
            cntSwReviews = cntSwReviews + 1
            
        if drType == "SDP_Full":
            sdpFullReviewDate = tempText
            sdpFullLastDRResult = lastDRResult
            sdpFullGeneralFindings = tempGeneralFindings
            sdpFullProcessFindings = tempProcessFindings
            sdpFullTechnicalFindings = tempTechnicalFindings
            noSwIdentified = False
            cntSwReviews = cntSwReviews + 1
            
        if drType == "SRS_Overall":
            srsOverallReviewDate = tempText
            srsOverallLastDRResult = lastDRResult
            srsOverallGeneralFindings = tempGeneralFindings
            srsOverallProcessFindings = tempProcessFindings
            srsOverallTechnicalFindings = tempTechnicalFindings
            noSwIdentified = False
            cntSwReviews = cntSwReviews + 1
                
        if drType == "Archi":
            archiReviewDate = tempText
            archiLastDRResult = lastDRResult
            archiGeneralFindings = tempGeneralFindings
            archiProcessFindings = tempProcessFindings
            archiTechnicalFindings = tempTechnicalFindings
            noSwIdentified = False
            cntSwReviews = cntSwReviews + 1
            
        if drType == "ITP":
            itpReviewDate = tempText
            itpLastDRResult = lastDRResult
            itpGeneralFindings = tempGeneralFindings
            itpProcessFindings = tempProcessFindings
            itpTechnicalFindings = tempTechnicalFindings
            noSwIdentified = False
            cntSwReviews = cntSwReviews + 1
            
        if drType == "VTP":
            vtpReviewDate = tempText
            vtpLastDRResult = lastDRResult
            vtpGeneralFindings = tempGeneralFindings
            vtpProcessFindings = tempProcessFindings
            vtpTechnicalFindings = tempTechnicalFindings
            noSwIdentified = False
            cntSwReviews = cntSwReviews + 1
            
        if drType == "SRS_Features":
            srsFeatureReviewDate = tempText
            srsFeatureLastDRResult = lastDRResult
            srsFeatureGeneralFindings = tempGeneralFindings
            srsFeatureProcessFindings = tempProcessFindings
            srsFeatureTechnicalFindings = tempTechnicalFindings
            noSwIdentified = False
            cntSwReviews = cntSwReviews + 1
            
        if drType == "Comp":
            compLastDRResult = lastDRResult
            compGeneralFindings = tempGeneralFindings
            compProcessFindings = tempProcessFindings
            compTechnicalFindings = tempTechnicalFindings
                                
            #Comp review is expected only if element is at least ASIL A
            if asil == "QM" :
                compReviewDate = "NA"
            else:
                compReviewDate = tempText
      
            noSwIdentified = False
            cntSwReviews = cntSwReviews + 1
                            
    if noSwIdentified == True :
        caavReviewDate = "No sw reviews identified under eDRM"
        sdpInitReviewDate = "No sw reviews identified under eDRM"
        sdpFullReviewDate = "No sw reviews identified under eDRM"
        srsOverallReviewDate = "No sw reviews identified under eDRM"
        archiReviewDate = "No sw reviews identified under eDRM"
        itpReviewDate = "No sw reviews identified under eDRM"
        vtpReviewDate = "No sw reviews identified under eDRM"
        srsFeatureReviewDate = "No sw reviews identified under eDRM"
        compReviewDate = "No sw reviews identified under eDRM"
        compMDBRebviewDate = "No sw reviews identified under eDRM"


def elaborateOverallSituation() :

    tempStatus = "Waiting for reviews"
    
    #Set GREEN status
    if cntGreenReviews > 0 and cntRedReviews == 0 and cntYellowReviews == 0 :
        tempStatus = "Green"
    
    #Set YELLOW status
    elif (cntRedReviews <= cntYellowReviews and (cntGreenReviews > 0 or cntGreenReviews == 0) and cntSwReviews > 0 ):
        tempStatus = "Yellow"
    
    #Set RED status
    elif cntRedReviews > cntYellowReviews :   
        tempStatus = "Red"
        
    
    if noSwIdentified == "True" :
        tempStatus = "No sw to be confirmed"    
    else :
        tempStatus = tempStatus

    #Return value
    tempStatus = ""
    overallSituation = tempStatus


if __name__ == "__main__":
    cntGreenReviews  = 0
    cntRedReviews   = 0
    cntYellowReviews  = 0
    cntSwReviews  = 0
    noSwIdentified  = True
    compute_data(19)